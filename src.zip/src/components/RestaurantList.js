import React, { Component } from 'react'

class RestaurantList extends Component {
  render() {
    return (
      <div>
        <h1>Explore</h1>
      </div>
    );
    
  }
}
export default  RestaurantList;

// import React from "react";

// function RestaurantList() {
//   return <div>RestaurantList</div>;
// }

// export default RestaurantList;
