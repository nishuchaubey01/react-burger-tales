import React, { Component } from 'react'

 class RestaurantUpdate extends Component {
  render() {
    return (
      <div>
        <h1>RestaurantUpdate</h1>
      </div>
    )
  }
}
export default  RestaurantUpdate;
