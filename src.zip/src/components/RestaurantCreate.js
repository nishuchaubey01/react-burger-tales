import React, { Component } from 'react'

class RestaurantCreate extends Component {
  render() {
    return (
      <div>
        <h1>RestaurantCreate</h1>
      </div>
    )
  }
}
export default  RestaurantCreate