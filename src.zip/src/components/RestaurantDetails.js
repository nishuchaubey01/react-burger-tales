import React, { Component } from 'react'

 class RestaurantDetails extends Component {
  render() {
    return (
      <div>
        <h1>Explore</h1>
      </div>
    );
  }
}
export default  RestaurantDetails;