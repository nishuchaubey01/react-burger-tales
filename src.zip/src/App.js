import React from "react";
import "./App.css";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";
import Home from "./components/Home";
import RestaurantCreate from "./components/RestaurantCreate";
import RestaurantDetails from "./components/RestaurantDetails";
import RestaurantList from "./components/RestaurantList";
import RestaurantSearch from "./components/RestaurantSearch";
import RestaurantUpdate from "./components/RestaurantUpdate";

function App() {
  return (
    <>
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/Create">Create</Link>
        </li>
        <li>
          <Link to="/Details">Details</Link>
        </li>
        <li>
          <Link to="/List">List</Link>
        </li>
        <li>
          <Link to="/Search">Search</Link>
        </li>
        <li>
          <Link to="/Update">Update</Link>
        </li>
      </ul>
      <Router>
        <Routes>
          <Route exact path="/List" component={RestaurantList} />
          {/* <Route path="/Create">
            <RestaurantCreate />
          </Route>
          <Route path="Details">
            <RestaurantDetails />
          </Route>
          <Route path="/Update">
            <RestaurantUpdate />
          </Route>
          <Route path="/Search">
            <RestaurantSearch />
          </Route>
          <Route path="/">
            <Home />
          </Route> */}
        </Routes>
      </Router>
    </>
  );
}

export default App;
